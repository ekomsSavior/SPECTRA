Synthetic teaching archive. Not a bootable firmware image.
The ARM routine does not read device.conf.
