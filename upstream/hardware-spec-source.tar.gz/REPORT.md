# Hardware architecture decompilation research

## Outcome

The **existing SPECTRA Pyre WASM engine** can genuinely decompile ARM, Thumb, AArch64, RISC-V, and MIPS. No engine replacement is required. Added SLEIGH assets, correct compiler/processor selection, and correct mapping are the missing integration pieces.

`node work/hardware-decompiler-research/prove_architectures.mjs` passed **27 actual Ghidra decompilation cases**, not mocked output:

- ARM 32 little/big endian additions and signed-count sum loops.
- Thumb little/big endian additions and loops. The additions start at an address ending in `...2`, proving halfword entry alignment.
- Cortex/Thumb little endian addition.
- AArch64 little/big *data* endian additions and loops, with little-endian instruction encoding in both profiles.
- RV32/RV64 regular addition, compressed `c.add`/`c.jr` addition, and loops. The compressed examples start at `...2`.
- MIPS32/MIPS64 little/big endian additions with **a non-NOP return delay slot** that adds one, and signed-count loops.

Every addition reconstructed `return param_1 + param_2;`; MIPS delay-slot tests correctly reconstructed `return param_1 + param_2 + 1;`. The loop fixtures became structured `do/while` or `for` loops. Exact bytes and expected/output source are in `proof-results.json`; the test script is reproducible from these pinned assets. This is initial architecture coverage, not a claim that every instruction/ABI or real-world optimized program has been validated.

## Provenance and reproducibility

- Existing Pyre source pin: `835d7dd871304966165339d8cc7ae2deb0d00789` ([source](https://github.com/ant4g0nist/pyre/tree/835d7dd871304966165339d8cc7ae2deb0d00789)).
- Existing WASM is unchanged: SHA256 `e1ccb27a0c32b7083fa61d2f8b073f058a92d71853f4cd6883072c9936cbfb9d`.
- Ghidra processor source: **Ghidra_12.0.3_build**, immutable commit `09f14c92d3da6e5d5f6b7dea115409719db3cce1` ([processor source](https://github.com/NationalSecurityAgency/ghidra/tree/09f14c92d3da6e5d5f6b7dea115409719db3cce1/Ghidra/Processors)). This is an explicit source pin chosen for compatibility, not an assertion that it is the latest release.
- Downloaded only source language folders for ARM, AARCH64, RISCV, MIPS: 121 files, 4,564,228 bytes. Per-file immutable URL and SHA256 are in `source-manifest.json`.
- `build_sleigh.py` compiles the SLEIGH compiler from the exact Pyre-vendored C++ source with local `g++ -std=c++17 -O2 -DNDEBUG`, not a newly mixed engine version. It uses system zlib for native compilation. No Emscripten rebuild is necessary.
- `compile_specs.py` builds 12 SLA outputs (ARM7/8 LE/BE, AArch64 LE/BE, RV32/64, MIPS32/64 LE/BE). Build diagnostics are preserved in `*.build.log`. Warnings include upstream NOP constructors and unused tables; compilation returns success. Do not equate specification inclusion with complete ISA modeling.
- `spec-manifest.json` hashes every untrimmed generated/copied asset.
- `prepare_profiles.py` creates the minimal runtime bundle and `bundle/hardware-specs.json`.
- Runtime bundle: **35 files, 3,063,317 bytes**, supporting 26 language/compiler combinations, with exact per-profile lazy-download lists. The 27 semantic tests exercise default compiler profiles; compiler variants beyond those are not all independently semantically tested.
- Preserve `GHIDRA-LICENSE` (Apache-2.0) and Ghidra/NSA attribution. The new specs are Ghidra 12.0.3 specs compiled with the Pyre-pinned SLEIGH compiler; the preexisting x86 specs remain from the Pyre pin. Do not call the whole WASM engine “Ghidra 12.0.3”.

## Correct profile choices

| Target | Tested Pyre language string | Entry alignment |
|---|---|---|
| ARM32 LE | `ARM:LE:32:v8:default` | 4 |
| ARM32 BE | `ARM:BE:32:v8:default` | 4 |
| Thumb LE | `ARM:LE:32:v8T:default` | 2 |
| Thumb BE | `ARM:BE:32:v8T:default` | 2 |
| Cortex/Thumb LE | `ARM:LE:32:Cortex:default` | 2 |
| AArch64 LE | `AARCH64:LE:64:v8A:default` | 4 |
| AArch64 BE data | `AARCH64:BE:64:v8A:default` | 4 (instructions LE) |
| RV32 | `RISCV:LE:32:default:gcc` | 2 |
| RV64 | `RISCV:LE:64:default:gcc` | 2 |
| MIPS32 LE/BE | `MIPS:LE:32:default:default` / `MIPS:BE:32:default:default` | 4 (ordinary ISA) |
| MIPS64 LE/BE | `MIPS:LE:64:default:default` / `MIPS:BE:64:default:default` | 4 (ordinary ISA) |

Additional upstream compiler ids: ARM `windows` (LE), `apcs`; AArch64 `windows` (LE); MIPS32 `windows`; MIPS64 LE `windows`. These are listed in the profile manifest. Do not mechanically append `:gcc` to all ELF profiles: ARM/AArch64/MIPS generally use `:default`, whereas RISCV uses `:gcc`.

The default MIPS32 cspec uses 32-bit pointers, whereas MIPS64 uses 64-bit pointers. Ghidra also offers `64-32addr` languages for `o32`, `o64`, `n32`, plus EABI variants, but those are intentionally outside this initial tested runtime profile set. ELF class alone is not a sufficient ABI detector for MIPS.

## Integration notes for current SPECTRA

1. `src/native-plan.js` currently rejects everything except x86/x64 and hardcodes the x86 language. Add a finite profile map with an architecture, bit width, endianness, and explicit override. Raw firmware needs analyst-selected base, entry, and profile.
2. `src/engines/native-worker.mjs` currently loads all x86 specs during eager init. Change it to fetch only the selected profile’s entries in `hardware-specs.json`, write them under `/spec/<arch>/data/languages`, and call `pyre_add_spec_dir` before `pyre_create`. Leave the x86 path working. Preserve exact allowlisting in the edge Worker.
3. A `.ldefs` file can list other language definitions whose SLA is not mounted; creation only needs the selected language’s SLA/pspec/cspec. Keep the UI constrained to the approved profile map; don't advertise all entries in upstream ldefs.
4. Existing `binary.js` reports `ARM`, `ARM Thumb`, `ARM64`, `MIPS`, `RISC-V`, plus `bits`/`endian`. Those names must map explicitly. For ARM it currently clears each ELF function-symbol low bit without storing whether it was set. Preserve a `thumb`/instruction-mode field before clearing it, so selecting a Thumb function from a mixed-mode ARM ELF chooses the correct profile.
5. The Pyre API has **no callable per-address context setter**. `ARMtTHUMB.pspec` sets the `TMode=1` default; `ARMt.pspec` sets zero. The upstream `v8T` profile solves selecting a Thumb entry today. Explicit per-region/per-function mode context across mixed ARM/Thumb code would need a bridge extension and separate tests; don't claim perfect mixed-mode recovery.
6. Thumb function pointers may contain the low state bit. Clear it for the actual mapped byte entry and keep mode as evidence. Do not blindly normalize arbitrary raw entries silently: show the normalized address/mode selection. Ordinary ARM requires word alignment; Thumb and compressed RISC-V permit halfword alignment.
7. MIPS delay slots are already modeled by the selected SLEIGH specs. Do **not** rewrite or omit the instruction after a branch/return, and keep bytes mapped through the delay slot. The proof specifically verifies a useful instruction in `jr $ra`'s delay slot.
8. RISCV specs include compressed instruction patterns and use two-byte alignment. These profiles are little-endian only. No big-endian RISC-V profiles were gathered/tested. The cspecs are the upstream floating-point (`ilp32d`/`lp64d`) ABIs: integer-only examples are fine, but don't promise accurate soft/single/quad-float or embedded RV32E prototypes.
9. ARM big-endian and ARM BE8 are different. Ordinary BE profiles use big-endian instructions/data; ELF `EF_ARM_BE8` means little-endian instructions with big-endian data. Upstream has `ARM:LEBE:32:v8LEInstruction`, but it is deliberately outside the tested initial profile set. Reject or request an explicit supported override for BE8 rather than feeding byte-swapped instructions to ordinary BE.
10. MIPS microMIPS, MIPS16, and Release 6 have distinct decoding/context semantics. Ordinary default profiles are not proof of those extensions. Use ELF flags to flag unsupported mode/ABI instead of silently producing plausible wrong output. Useful flags found in local `/usr/include/elf.h`: `EF_MIPS_ARCH_ASE_MICROMIPS=0x02000000`, `EF_MIPS_ARCH_ASE_M16=0x04000000`, `EF_MIPS_ARCH` mask `0xf0000000`, R6 architecture values `0x90000000`/`0xa0000000`, and `EF_MIPS_ABI2=0x20` (n32).
11. Record ELF `e_flags` (ELF32 offset36, ELF64 offset48, file byte order). Other useful distinctions: `EF_ARM_BE8=0x00800000`, ARM float ABI soft/hard `0x200`/`0x400`; RISC-V float ABI mask `0x6`, RV32E flag `0x8`, compressed flag `0x1`.
12. Preserve current input/mapping/output bounds, cancellation, worker isolation, and text-only rendering. This engine still has an expandable WASM heap; the 27-test process reached **96,665,600 bytes** when loading all four architecture groups. Lazy per-profile initialization avoids unnecessary downloads and retained translator state on modest machines. Terminate disposable workers after cancellation/fault.
13. These changes enable native decompilation, not architecture emulation in the current x86-only debugger. Keep those feature claims separate.

## What “optimization” should mean here

The Ghidra decompiler already performs p-code analysis, constant propagation, variable recovery, and control-flow structuring regardless of ISA. Correct ISA mode, calling convention, load address, symbol names, and data types improve its input. There is no evidence-based reason to bolt a text rewrite onto the output and call it optimization.

For the next stage, useful measurable targets are optimized compiler fixtures (`-O0/-O2/-Os` with matching source), MIPS PIC/`gp` recovery, ARM literal pools and Thumb mode transitions, RISC-V relaxation/GP-relative references, relocation awareness, switch tables, and user-adjustable prototypes/types. Keep expected behavior and limitations visible in tests. Current proofs are compact hand-encoded benign functions, not compiler-generated optimization benchmarks.

No SPECTRA app files were edited or deployed. `work/pyre` was not touched.
