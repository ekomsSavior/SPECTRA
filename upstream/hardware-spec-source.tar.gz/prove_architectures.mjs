import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import PyreDecompiler from '../native-decompiler-research/pyre/pyre_decompiler.mjs';
const root=path.dirname(new URL(import.meta.url).pathname);
const mod=await PyreDecompiler({wasmBinary:new Uint8Array(fs.readFileSync(new URL('../native-decompiler-research/pyre/pyre_decompiler.wasm',import.meta.url))),print:()=>{},printErr:console.error});
const bind=(n,r,a)=>mod.cwrap(n,r,a);
const api={dir:bind('pyre_add_spec_dir','number',['string']),create:bind('pyre_create','number',['string']),region:bind('pyre_add_region','number',['number','bigint','number','number']),symbol:bind('pyre_add_symbol','number',['number','bigint','string']),decompile:bind('pyre_decompile','number',['number','bigint','string']),free:bind('pyre_free_string',null,['number']),destroy:bind('pyre_destroy',null,['number'])};
for(const arch of ['ARM','AARCH64','RISCV','MIPS']){
 const dir='/spec/'+arch+'/data/languages';mod.FS.mkdirTree(dir);
 for(const name of fs.readdirSync(path.join(root,'specs',arch,'data/languages')))mod.FS.writeFile(dir+'/'+name,new Uint8Array(fs.readFileSync(path.join(root,'specs',arch,'data/languages',name))));
 assert.equal(api.dir(dir),0);
}
const cases=[
 {language:'ARM:LE:32:v8:default',name:'arm_add',hex:'010080e01eff2fe1'},
 {language:'ARM:BE:32:v8:default',name:'arm_be_add',hex:'e0800001e12fff1e'},
 {language:'ARM:LE:32:v8T:default',name:'thumb_add',hex:'40187047',base:0x1002},
 {language:'ARM:BE:32:v8T:default',name:'thumb_be_add',hex:'18404770',base:0x1002},
 {language:'ARM:LE:32:Cortex:default',name:'cortex_add',hex:'40187047',base:0x1002},
 {language:'AARCH64:LE:64:v8A:default',name:'aarch64_add',hex:'0000018bc0035fd6'},
 {language:'AARCH64:BE:64:v8A:default',name:'aarch64_be_add',hex:'0000018bc0035fd6'},
 {language:'RISCV:LE:32:default:gcc',name:'rv32_add',hex:'3305b50067800000'},
 {language:'RISCV:LE:64:default:gcc',name:'rv64_add',hex:'3305b50067800000'},
 {language:'RISCV:LE:32:default:gcc',name:'rv32_compressed_add',hex:'2e958280',base:0x1002},
 {language:'RISCV:LE:64:default:gcc',name:'rv64_compressed_add',hex:'2e958280',base:0x1002},
 {language:'MIPS:BE:32:default:default',name:'mips32_be_add_with_delay',hex:'0085102103e0000824420001',delay:true},
 {language:'MIPS:LE:32:default:default',name:'mips32_le_add_with_delay',hex:'211085000800e00301004224',delay:true},
 {language:'MIPS:BE:64:default:default',name:'mips64_be_add_with_delay',hex:'0085102d03e0000864420001',delay:true},
 {language:'MIPS:LE:64:default:default',name:'mips64_le_add_with_delay',hex:'2d1085000800e00301004264',delay:true},
];
const words=(values,little=true,bits=32)=>values.map(n=>{const b=Buffer.alloc(bits/8);if(bits===16)(little?b.writeUInt16LE:b.writeUInt16BE).call(b,n);else(little?b.writeUInt32LE:b.writeUInt32BE).call(b,n);return b.toString('hex');}).join('');
const armLoop=[0xe3a01000,0xe3500000,0xda000002,0xe0811000,0xe2500001,0x1afffffc,0xe1a00001,0xe12fff1e];
const thumbLoop=[0x2100,0x2800,0xdd02,0x1809,0x3801,0xd1fc,0x4608,0x4770];
const a64Loop=[0xd2800001,0xf100001f,0x5400008d,0x8b000021,0xf1000400,0x54ffffc1,0xaa0103e0,0xd65f03c0];
const rvLoop=[0x00000593,0x00a05863,0x00a585b3,0xfff50513,0xfe051ce3,0x00058513,0x00008067];
for(const endian of ['LE','BE']){
 cases.push({language:`ARM:${endian}:32:v8:default`,name:'arm_loop_'+endian,hex:words(armLoop,endian==='LE'),loop:true});
 cases.push({language:`ARM:${endian}:32:v8T:default`,name:'thumb_loop_'+endian,hex:words(thumbLoop,endian==='LE',16),loop:true});
 cases.push({language:`AARCH64:${endian}:64:v8A:default`,name:'a64_loop_'+endian,hex:words(a64Loop),loop:true});
 for(const width of [32,64]){
  const mipsLoop=[width===32?0x00001021:0x0000102d,0x18800005,0,width===32?0x00441021:0x0044102d,width===32?0x2484ffff:0x6484ffff,0x1c80fffd,0,0x03e00008,0];
  cases.push({language:`MIPS:${endian}:${width}:default:default`,name:`mips${width}_loop_${endian}`,hex:words(mipsLoop,endian==='LE'),loop:true});
 }
}
for(const width of [32,64])cases.push({language:`RISCV:LE:${width}:default:gcc`,name:`rv${width}_loop`,hex:words(rvLoop),loop:true});
const results=[];
for(const test of cases){
 const h=api.create(test.language);assert.ok(h,'create '+test.language);
 const bytes=Buffer.from(test.hex,'hex'),ptr=mod._malloc(bytes.length),base=BigInt(test.base??0x1000);mod.HEAPU8.set(bytes,ptr);
 assert.equal(api.region(h,base,ptr,bytes.length),0);mod._free(ptr);assert.equal(api.symbol(h,base,test.name),0);
 const p=api.decompile(h,base,test.name);assert.ok(p);const code=mod.UTF8ToString(p);api.free(p);api.destroy(h);
 console.log(test.language+' '+test.name+'\n'+code);
 assert.doesNotMatch(code,/decompile error|unaff_|halt_baddata|WARNING/);
 if(test.loop)assert.match(code,/(?:while|for) \(/);else assert.match(code,/return param_1 \+ param_2/);
 if(test.delay)assert.match(code,/param_2 \+ 1/);
 results.push({...test,base:Number(base),code,passed:true});
}
fs.writeFileSync(path.join(root,'proof-results.json'),JSON.stringify({engine:'existing SPECTRA Pyre WASM',memoryBytes:mod.HEAPU8.byteLength,passed:results.length,results},null,2)+'\n');
console.log('PASS',results.length,'memory',mod.HEAPU8.byteLength);
